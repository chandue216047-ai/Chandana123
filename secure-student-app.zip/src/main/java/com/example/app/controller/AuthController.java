package com.example.app.controller;

import com.example.app.service.AuthService;
import jakarta.validation.constraints.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth){this.auth=auth;}

    public record LoginRequest(@NotBlank String username,@NotBlank String password){}
    public record TokenResponse(String token){}

    @PostMapping("/login")
    public TokenResponse login(@RequestBody LoginRequest r){
        return new TokenResponse(auth.login(r.username(),r.password()));
    }
}
