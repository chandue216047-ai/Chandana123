package com.example.app.controller;

import com.example.app.model.*;
import com.example.app.repository.UserRepository;
import com.example.app.security.JwtService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.http.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;

    public AuthController(UserRepository users, PasswordEncoder encoder, JwtService jwt){
        this.users=users; this.encoder=encoder; this.jwt=jwt;
    }

    public record LoginRequest(@NotBlank String username,@NotBlank String password){}
    public record RegisterRequest(@NotBlank String username,@NotBlank String password){}

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest r){
        if(users.findByUsername(r.username()).isPresent())
            return ResponseEntity.badRequest().body("Username already exists");
        User u=new User(); u.setUsername(r.username());
        u.setPassword(encoder.encode(r.password())); u.setRole(Role.USER);
        users.save(u);
        return ResponseEntity.ok("Registered");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest r){
        var u=users.findByUsername(r.username()).orElse(null);
        if(u==null || !encoder.matches(r.password(),u.getPassword()))
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        return ResponseEntity.ok(java.util.Map.of("token",jwt.generate(u.getUsername(),u.getRole().name()),
                                                "role",u.getRole().name()));
    }
}