package com.example.app.controller;

import com.example.app.model.Student;
import com.example.app.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentService service;
    public StudentController(StudentService service){this.service=service;}

    @GetMapping public List<Student> all(){return service.all();}

    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping public Student add(@Valid @RequestBody Student s){return service.save(s);}

    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){service.delete(id);}
}
