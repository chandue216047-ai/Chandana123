package com.example.app.controller;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestControllerAdvice
public class ErrorHandler {
    @ExceptionHandler(Exception.class)
    ResponseEntity<Map<String,String>> handle(Exception e){
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
            .body(Map.of("error","Request could not be processed"));
    }
}
