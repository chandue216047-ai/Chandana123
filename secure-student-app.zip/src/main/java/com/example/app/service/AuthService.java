package com.example.app.service;

import com.example.app.repository.UserRepository;
import com.example.app.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UserRepository users; private final PasswordEncoder encoder; private final JwtService jwt;
    public AuthService(UserRepository users,PasswordEncoder encoder,JwtService jwt){
        this.users=users;this.encoder=encoder;this.jwt=jwt;
    }
    public String login(String username,String password){
        var u=users.findByUsername(username)
            .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        if(!encoder.matches(password,u.getPassword()))
            throw new RuntimeException("Invalid credentials");
        return jwt.generate(u.getUsername(),u.getRole().name());
    }
}
