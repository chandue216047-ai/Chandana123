package com.example.app.config;

import com.example.app.model.*;
import com.example.app.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class AppConfig {
    @Bean CommandLineRunner seed(UserRepository repo, PasswordEncoder encoder) {
        return args -> {
            if(repo.findByUsername("admin").isEmpty())
                repo.save(new User("admin", encoder.encode("Admin@12345"), Role.ADMIN));
            if(repo.findByUsername("user").isEmpty())
                repo.save(new User("user", encoder.encode("User@12345"), Role.USER));
        };
    }
}
