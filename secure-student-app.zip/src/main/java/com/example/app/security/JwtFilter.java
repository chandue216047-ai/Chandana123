package com.example.app.security;

import com.example.app.repository.UserRepository;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;
import java.util.List;

@Component
public class JwtFilter extends OncePerRequestFilter {
    private final JwtService jwtService;
    private final UserRepository users;

    public JwtFilter(JwtService jwtService, UserRepository users) {
        this.jwtService=jwtService; this.users=users;
    }

    @Override protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
            FilterChain chain) throws ServletException, IOException {
        String h=req.getHeader("Authorization");
        if(h!=null && h.startsWith("Bearer ")) {
            try {
                var claims=jwtService.parse(h.substring(7));
                String username=claims.getSubject();
                var user=users.findByUsername(username).orElseThrow();
                var auth=new UsernamePasswordAuthenticationToken(
                    username,null,List.of(new SimpleGrantedAuthority("ROLE_"+user.getRole().name())));
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch(Exception ignored) {}
        }
        chain.doFilter(req,res);
    }
}