package com.example.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name="students")
public class Student {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @NotBlank @Size(max=100)
    private String name;
    @NotBlank @Email @Size(max=150)
    private String email;
    @NotBlank @Size(max=100)
    private String course;

    public Long getId(){return id;}
    public String getName(){return name;}
    public String getEmail(){return email;}
    public String getCourse(){return course;}
    public void setName(String v){name=v;}
    public void setEmail(String v){email=v;}
    public void setCourse(String v){course=v;}
}
