package com.example.app.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@Entity
public class Student {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @NotBlank private String name;
    @NotBlank @Email private String email;
    @NotBlank private String course;

    public Long getId(){ return id; }
    public String getName(){ return name; }
    public void setName(String name){ this.name=name; }
    public String getEmail(){ return email; }
    public void setEmail(String email){ this.email=email; }
    public String getCourse(){ return course; }
    public void setCourse(String course){ this.course=course; }
}