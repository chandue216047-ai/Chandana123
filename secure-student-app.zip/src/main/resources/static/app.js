const tokenKey="student_jwt";
function token(){return localStorage.getItem(tokenKey);}
async function api(url,options={}){
  options.headers={...(options.headers||{}),"Content-Type":"application/json"};
  if(token()) options.headers.Authorization="Bearer "+token();
  return fetch(url,options);
}
document.getElementById("loginForm")?.addEventListener("submit",async e=>{
 e.preventDefault();
 const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},
 body:JSON.stringify({username:username.value,password:password.value})});
 if(r.ok){localStorage.setItem(tokenKey,(await r.json()).token);location="/students.html";}
 else msg.textContent="Login failed";
});
async function loadStudents(){
 const r=await api("/api/students");
 if(r.status===401){location="/login.html";return;}
 out.textContent=JSON.stringify(await r.json(),null,2);
}
document.getElementById("studentForm")?.addEventListener("submit",async e=>{
 e.preventDefault();
 const r=await api("/api/students",{method:"POST",body:JSON.stringify({name:name.value,email:email.value,course:course.value})});
 out.textContent=r.ok?"Student added":await r.text(); if(r.ok) loadStudents();
});
function logout(){localStorage.removeItem(tokenKey);location="/login.html";}
