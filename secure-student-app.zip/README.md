# Secure Student FSD Application

## Stack
- HTML/JavaScript
- Java 17 + Spring Boot
- Spring Security
- JWT
- BCrypt
- Spring Data JPA
- MySQL

## Security layers included
1. HTTPS/TLS deployment point
2. Backend validation
3. BCrypt password hashing
4. JWT authentication
5. USER/ADMIN authorization
6. JPA repository instead of SQL concatenation
7. CORS configuration
8. Stateless API CSRF design note
9. Basic XSS-safe frontend example
10. Rate-limiting deployment point
11. Security configuration
12. Environment-based secrets
13. Global error handling

## Run
1. Install Java 17, Maven and MySQL.
2. Create database:
   CREATE DATABASE secure_student;
3. Set DB_USERNAME and DB_PASSWORD if needed.
4. Set a strong JWT_SECRET for real use.
5. Run:
   mvn spring-boot:run
6. Open http://localhost:8080/login.html

## Important
Registration creates USER accounts. To test ADMIN endpoints, change a user's role in MySQL:
UPDATE users SET role='ADMIN' WHERE username='yourusername';

For production, use HTTPS, a strong secret manager, proper rate limiting, security headers/CSP, monitoring, backups, and CSRF protection if switching to cookie-based authentication.
