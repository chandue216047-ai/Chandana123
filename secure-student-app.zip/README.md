# Secure Student Management FSD App

Stack: HTML/CSS/JavaScript + Spring Boot + Spring Security + JWT + BCrypt + MySQL.

## Run
1. Create MySQL database: `CREATE DATABASE secure_student;`
2. Set environment variables:
   - DB_USERNAME
   - DB_PASSWORD
   - JWT_SECRET (Base64 secret, at least 256 bits)
3. Run: `mvn spring-boot:run`
4. Open `http://localhost:8080/login.html`

Demo users are created automatically:
- admin / Admin@12345
- user / User@12345

Security included: validation, BCrypt, JWT authentication, role authorization, CORS, CSRF-compatible stateless API design, security headers, basic login rate limiting, safe error responses, and environment-based secrets.

For production, put the app behind HTTPS and replace demo credentials/rate limiter with a production-grade solution.
